create procedure get_forms(IN user int)
  BEGIN
SELECT forms.form_id, questions.question_id, questions.label, questions.q_type FROM questions INNER JOIN forms WHERE (forms.userId = user);
END;

